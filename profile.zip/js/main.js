document.addEventListener('DOMContentLoaded', () => {
    // Set current year in the footer
    const currentYearSpan = document.getElementById('current-year');
    if (currentYearSpan) {
        currentYearSpan.textContent = new Date().getFullYear();
    }

    // Smooth scroll for anchor links (if any were added later)
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Intersection Observer for scroll-triggered animations (reveal effect)
    const revealElements = document.querySelectorAll('.reveal');

    const observerOptions = {
        root: null, // viewport
        rootMargin: '0px',
        threshold: 0.2 // Trigger when 20% of the element is visible
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target); // Stop observing once animated
            }
        });
    }, observerOptions);

    revealElements.forEach(el => {
        observer.observe(el);
    });

    // Optional: Add a subtle parallax effect to the hero image on scroll
    const heroImageContainer = document.querySelector('.hero-image-container');
    if (heroImageContainer) {
        window.addEventListener('scroll', () => {
            const scrollDistance = window.scrollY;
            heroImageContainer.style.transform = `translateY(${scrollDistance * 0.15}px)`; // Adjust 0.15 for more/less parallax
        });
    }

});